<H4>Back up Status</H4>

<?php
if($return==0){ echo "Backup was Successful";}else{ echo "Backup failed"; }
?>