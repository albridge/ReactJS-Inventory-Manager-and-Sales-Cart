<div style="margin:auto; margin-top:50px; text-align:center; font-weight:bold; font-size:16px; color:red;">

Balance payment pending. Call Steve on 08035143000 to balance payment and continue using software!
</div>
