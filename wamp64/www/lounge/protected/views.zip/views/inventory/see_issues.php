<script type="text/javascript">



</script>
<h1>See Issues</h1>
<div id="loading" style="display:none;"><?= CHtml::image(Yii::app()->baseUrl . "/loader/loader11.gif","",array("style"=>"")); ?></div>
<div id="go_issues"></div>


<script type="text/javascript">
	window.onload = function(){
   to_issues();
}
</script>